1. What You CAN Do
✅ Use it in any game, whether you sell your game or give it away for free.

✅ Modify or recolor it to fit your project.

2. What You CANNOT Do
❌ Resell or share the raw Asset on its own (for example, in an art pack).

❌ Claim it as your own original work, even if you change it.

❌ Use it to train AI or feed into machine learning models.

3. Redistribution Rules
You may include the Asset inside your finished game or app.

You may not hand out or sell the Asset file by itself.

4. Credit & Attribution
Giving credit "Goblin art by Soul sire" is nice but not required.